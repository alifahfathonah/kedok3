<?php
get_template_part('u-member/classic','list-item');
?>
